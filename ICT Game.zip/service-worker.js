/* ============================================================
   প্রাণী গেম — Service Worker
   Offline-first caching for Bangladesh students
   ============================================================ */

const CACHE_NAME    = 'prani-game-v1';
const CACHE_ASSETS  = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

/* ----------------------------------------------------------
   INSTALL — Pre-cache all essential assets
   ---------------------------------------------------------- */
self.addEventListener('install', event => {
  console.log('[SW] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[SW] Pre-caching assets');
      return cache.addAll(CACHE_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

/* ----------------------------------------------------------
   ACTIVATE — Clean up old caches
   ---------------------------------------------------------- */
self.addEventListener('activate', event => {
  console.log('[SW] Activating...');
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(key => key !== CACHE_NAME)
          .map(key => {
            console.log('[SW] Deleting old cache:', key);
            return caches.delete(key);
          })
      )
    ).then(() => self.clients.claim())
  );
});

/* ----------------------------------------------------------
   FETCH — Cache-first strategy (great for low-data users)
   ---------------------------------------------------------- */
self.addEventListener('fetch', event => {
  // Only handle GET requests
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then(cachedResponse => {
      if (cachedResponse) {
        // Serve from cache immediately (offline works!)
        return cachedResponse;
      }

      // Not in cache — try network, then cache the response
      return fetch(event.request)
        .then(networkResponse => {
          if (
            !networkResponse ||
            networkResponse.status !== 200 ||
            networkResponse.type === 'opaque'
          ) {
            return networkResponse;
          }

          // Clone and store in cache for next time
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseToCache);
          });

          return networkResponse;
        })
        .catch(() => {
          // Fully offline and not in cache — serve fallback
          if (event.request.destination === 'document') {
            return caches.match('./index.html');
          }
          // For other resources, return empty 503
          return new Response('Offline', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: new Headers({ 'Content-Type': 'text/plain' })
          });
        });
    })
  );
});

/* ----------------------------------------------------------
   MESSAGE — Force update from app
   ---------------------------------------------------------- */
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
